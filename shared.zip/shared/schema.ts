import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// === USERS ===
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  role: text("role").notNull().default("student"), // 'student', 'alumni'
  fullName: text("full_name").notNull(),
  batch: text("batch"), // e.g., "2024"
  domain: text("domain"), // e.g., "Computer Science"
  company: text("company"), // For alumni
  isVerified: boolean("is_verified").default(false),
  avatarUrl: text("avatar_url"),
  bio: text("bio"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  contactLinkedIn: text("contact_linkedin"),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true });
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

// === MARKETPLACE ===
export const marketplaceItems = pgTable("marketplace_items", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  price: integer("price").notNull(), // in cents or currency unit
  condition: text("condition").notNull(), // 'new', 'used', 'fair'
  category: text("category").notNull(), // 'electronics', 'books', 'tools'
  sellerId: integer("seller_id").notNull(),
  status: text("status").default("available"), // 'available', 'sold'
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertMarketplaceItemSchema = createInsertSchema(marketplaceItems).omit({ id: true, createdAt: true });
export type MarketplaceItem = typeof marketplaceItems.$inferSelect;
export type InsertMarketplaceItem = z.infer<typeof insertMarketplaceItemSchema>;

// === LOST & FOUND ===
export const lostFoundItems = pgTable("lost_found_items", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  type: text("type").notNull(), // 'lost', 'found'
  reporterId: integer("reporter_id").notNull(),
  status: text("status").default("reported"), // 'reported', 'claimed', 'resolved'
  imageUrl: text("image_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertLostFoundItemSchema = createInsertSchema(lostFoundItems).omit({ id: true, createdAt: true });
export type LostFoundItem = typeof lostFoundItems.$inferSelect;
export type InsertLostFoundItem = z.infer<typeof insertLostFoundItemSchema>;

// === ACADEMY (NOTES) ===
export const academyResources = pgTable("academy_resources", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  subject: text("subject").notNull(),
  description: text("description"),
  uploaderId: integer("uploader_id").notNull(),
  fileUrl: text("file_url").notNull(),
  tags: text("tags").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAcademyResourceSchema = createInsertSchema(academyResources).omit({ id: true, createdAt: true });
export type AcademyResource = typeof academyResources.$inferSelect;
export type InsertAcademyResource = z.infer<typeof insertAcademyResourceSchema>;

// === INTERNSHIPS ===
export const internships = pgTable("internships", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  company: text("company").notNull(),
  type: text("type").notNull(), // 'remote', 'onsite', 'hybrid'
  domain: text("domain").notNull(),
  description: text("description").notNull(),
  applyLink: text("apply_link"),
  stipend: text("stipend"),
  postedById: integer("posted_by_id"), // Could be admin or alumni
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertInternshipSchema = createInsertSchema(internships).omit({ id: true, createdAt: true });
export type Internship = typeof internships.$inferSelect;
export type InsertInternship = z.infer<typeof insertInternshipSchema>;

// === REFERRALS ===
export const referrals = pgTable("referrals", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(), // Job role
  company: text("company").notNull(),
  referrerId: integer("referrer_id").notNull(),
  description: text("description").notNull(),
  requirements: text("requirements"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertReferralSchema = createInsertSchema(referrals).omit({ id: true, createdAt: true });
export type Referral = typeof referrals.$inferSelect;
export type InsertReferral = z.infer<typeof insertReferralSchema>;

// === RELATIONS ===
// (Simplified for now, assume IDs are valid)
