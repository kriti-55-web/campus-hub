import { z } from 'zod';
import { 
  insertUserSchema, 
  insertMarketplaceItemSchema, 
  insertLostFoundItemSchema, 
  insertAcademyResourceSchema,
  insertInternshipSchema,
  insertReferralSchema,
  users, marketplaceItems, lostFoundItems, academyResources, internships, referrals
} from './schema';

export const errorSchemas = {
  validation: z.object({
    message: z.string(),
    field: z.string().optional(),
  }),
  notFound: z.object({
    message: z.string(),
  }),
  internal: z.object({
    message: z.string(),
  }),
};

export const api = {
  users: {
    login: {
      method: 'POST' as const,
      path: '/api/users/login',
      input: z.object({ username: z.string(), password: z.string() }),
      responses: {
        200: z.custom<typeof users.$inferSelect>(),
        401: errorSchemas.validation,
      }
    },
    register: {
      method: 'POST' as const,
      path: '/api/users/register',
      input: insertUserSchema,
      responses: {
        201: z.custom<typeof users.$inferSelect>(),
        400: errorSchemas.validation,
      }
    },
    list: {
      method: 'GET' as const,
      path: '/api/users',
      input: z.object({ role: z.enum(['student', 'alumni']).optional() }).optional(),
      responses: {
        200: z.array(z.custom<typeof users.$inferSelect>()),
      }
    }
  },
  marketplace: {
    list: {
      method: 'GET' as const,
      path: '/api/marketplace',
      input: z.object({ category: z.string().optional() }).optional(),
      responses: {
        200: z.array(z.custom<typeof marketplaceItems.$inferSelect>()),
      }
    },
    create: {
      method: 'POST' as const,
      path: '/api/marketplace',
      input: insertMarketplaceItemSchema,
      responses: {
        201: z.custom<typeof marketplaceItems.$inferSelect>(),
      }
    }
  },
  lostFound: {
    list: {
      method: 'GET' as const,
      path: '/api/lost-found',
      input: z.object({ type: z.enum(['lost', 'found']).optional() }).optional(),
      responses: {
        200: z.array(z.custom<typeof lostFoundItems.$inferSelect>()),
      }
    },
    create: {
      method: 'POST' as const,
      path: '/api/lost-found',
      input: insertLostFoundItemSchema,
      responses: {
        201: z.custom<typeof lostFoundItems.$inferSelect>(),
      }
    }
  },
  academy: {
    list: {
      method: 'GET' as const,
      path: '/api/academy',
      input: z.object({ subject: z.string().optional() }).optional(),
      responses: {
        200: z.array(z.custom<typeof academyResources.$inferSelect>()),
      }
    },
    create: {
      method: 'POST' as const,
      path: '/api/academy',
      input: insertAcademyResourceSchema,
      responses: {
        201: z.custom<typeof academyResources.$inferSelect>(),
      }
    }
  },
  internships: {
    list: {
      method: 'GET' as const,
      path: '/api/internships',
      input: z.object({ domain: z.string().optional() }).optional(),
      responses: {
        200: z.array(z.custom<typeof internships.$inferSelect>()),
      }
    },
    create: {
      method: 'POST' as const,
      path: '/api/internships',
      input: insertInternshipSchema,
      responses: {
        201: z.custom<typeof internships.$inferSelect>(),
      }
    }
  },
  referrals: {
    list: {
      method: 'GET' as const,
      path: '/api/referrals',
      responses: {
        200: z.array(z.custom<typeof referrals.$inferSelect>()),
      }
    },
    create: {
      method: 'POST' as const,
      path: '/api/referrals',
      input: insertReferralSchema,
      responses: {
        201: z.custom<typeof referrals.$inferSelect>(),
      }
    }
  }
};

export function buildUrl(path: string, params?: Record<string, string | number>): string {
  let url = path;
  if (params) {
    Object.entries(params).forEach(([key, value]) => {
      if (url.includes(`:${key}`)) {
        url = url.replace(`:${key}`, String(value));
      }
    });
  }
  return url;
}
