import { db } from "./db";
import { 
  users, marketplaceItems, lostFoundItems, academyResources, internships, referrals,
  type InsertUser, type InsertMarketplaceItem, type InsertLostFoundItem, 
  type InsertAcademyResource, type InsertInternship, type InsertReferral
} from "@shared/schema";
import { eq, ilike } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<typeof users.$inferSelect | undefined>;
  getUserByUsername(username: string): Promise<typeof users.$inferSelect | undefined>;
  createUser(user: InsertUser): Promise<typeof users.$inferSelect>;
  getUsersByRole(role?: string): Promise<typeof users.$inferSelect[]>;

  // Marketplace
  getMarketplaceItems(category?: string): Promise<typeof marketplaceItems.$inferSelect[]>;
  createMarketplaceItem(item: InsertMarketplaceItem): Promise<typeof marketplaceItems.$inferSelect>;

  // Lost & Found
  getLostFoundItems(type?: string): Promise<typeof lostFoundItems.$inferSelect[]>;
  createLostFoundItem(item: InsertLostFoundItem): Promise<typeof lostFoundItems.$inferSelect>;

  // Academy
  getAcademyResources(subject?: string): Promise<typeof academyResources.$inferSelect[]>;
  createAcademyResource(resource: InsertAcademyResource): Promise<typeof academyResources.$inferSelect>;

  // Internships
  getInternships(domain?: string): Promise<typeof internships.$inferSelect[]>;
  createInternship(internship: InsertInternship): Promise<typeof internships.$inferSelect>;

  // Referrals
  getReferrals(): Promise<typeof referrals.$inferSelect[]>;
  createReferral(referral: InsertReferral): Promise<typeof referrals.$inferSelect>;
}

export class DatabaseStorage implements IStorage {
  // Users
  async getUser(id: number) {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }
  async getUserByUsername(username: string) {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }
  async createUser(user: InsertUser) {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }
  async getUsersByRole(role?: string) {
    if (role) {
      return await db.select().from(users).where(eq(users.role, role));
    }
    return await db.select().from(users);
  }

  // Marketplace
  async getMarketplaceItems(category?: string) {
    if (category) {
      return await db.select().from(marketplaceItems).where(eq(marketplaceItems.category, category));
    }
    return await db.select().from(marketplaceItems);
  }
  async createMarketplaceItem(item: InsertMarketplaceItem) {
    const [newItem] = await db.insert(marketplaceItems).values(item).returning();
    return newItem;
  }

  // Lost & Found
  async getLostFoundItems(type?: string) {
    if (type) {
      return await db.select().from(lostFoundItems).where(eq(lostFoundItems.type, type));
    }
    return await db.select().from(lostFoundItems);
  }
  async createLostFoundItem(item: InsertLostFoundItem) {
    const [newItem] = await db.insert(lostFoundItems).values(item).returning();
    return newItem;
  }

  // Academy
  async getAcademyResources(subject?: string) {
    if (subject) {
      return await db.select().from(academyResources).where(eq(academyResources.subject, subject));
    }
    return await db.select().from(academyResources);
  }
  async createAcademyResource(resource: InsertAcademyResource) {
    const [newResource] = await db.insert(academyResources).values(resource).returning();
    return newResource;
  }

  // Internships
  async getInternships(domain?: string) {
    if (domain) {
      return await db.select().from(internships).where(eq(internships.domain, domain));
    }
    return await db.select().from(internships);
  }
  async createInternship(internship: InsertInternship) {
    const [newInternship] = await db.insert(internships).values(internship).returning();
    return newInternship;
  }

  // Referrals
  async getReferrals() {
    return await db.select().from(referrals);
  }
  async createReferral(referral: InsertReferral) {
    const [newReferral] = await db.insert(referrals).values(referral).returning();
    return newReferral;
  }
}

export const storage = new DatabaseStorage();
