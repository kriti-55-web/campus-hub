import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  
  // Users
  app.post(api.users.register.path, async (req, res) => {
    try {
      const input = api.users.register.input.parse(req.body);
      const existing = await storage.getUserByUsername(input.username);
      if (existing) {
        return res.status(400).json({ message: "Username already exists" });
      }
      const user = await storage.createUser(input);
      res.status(201).json(user);
    } catch (err) {
      if (err instanceof z.ZodError) {
        res.status(400).json({ message: err.errors[0].message });
      } else {
        res.status(500).json({ message: "Internal server error" });
      }
    }
  });

  app.post(api.users.login.path, async (req, res) => {
    try {
      const input = api.users.login.input.parse(req.body);
      const user = await storage.getUserByUsername(input.username);
      if (!user || user.password !== input.password) {
        return res.status(401).json({ message: "Invalid credentials" });
      }
      res.json(user);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  app.get(api.users.list.path, async (req, res) => {
    const role = req.query.role as string | undefined;
    const users = await storage.getUsersByRole(role);
    res.json(users);
  });

  // Marketplace
  app.get(api.marketplace.list.path, async (req, res) => {
    const category = req.query.category as string | undefined;
    const items = await storage.getMarketplaceItems(category);
    res.json(items);
  });

  app.post(api.marketplace.create.path, async (req, res) => {
    try {
      const input = api.marketplace.create.input.parse(req.body);
      const item = await storage.createMarketplaceItem(input);
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // Lost & Found
  app.get(api.lostFound.list.path, async (req, res) => {
    const type = req.query.type as string | undefined;
    const items = await storage.getLostFoundItems(type);
    res.json(items);
  });

  app.post(api.lostFound.create.path, async (req, res) => {
    try {
      const input = api.lostFound.create.input.parse(req.body);
      const item = await storage.createLostFoundItem(input);
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // Academy
  app.get(api.academy.list.path, async (req, res) => {
    const subject = req.query.subject as string | undefined;
    const resources = await storage.getAcademyResources(subject);
    res.json(resources);
  });

  app.post(api.academy.create.path, async (req, res) => {
    try {
      const input = api.academy.create.input.parse(req.body);
      const resource = await storage.createAcademyResource(input);
      res.status(201).json(resource);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // Internships
  app.get(api.internships.list.path, async (req, res) => {
    const domain = req.query.domain as string | undefined;
    const items = await storage.getInternships(domain);
    res.json(items);
  });

  app.post(api.internships.create.path, async (req, res) => {
    try {
      const input = api.internships.create.input.parse(req.body);
      const item = await storage.createInternship(input);
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // Referrals
  app.get(api.referrals.list.path, async (req, res) => {
    const items = await storage.getReferrals();
    res.json(items);
  });

  app.post(api.referrals.create.path, async (req, res) => {
    try {
      const input = api.referrals.create.input.parse(req.body);
      const item = await storage.createReferral(input);
      res.status(201).json(item);
    } catch (err) {
      res.status(400).json({ message: "Invalid input" });
    }
  });

  // SEED DATA
  try {
    const existingUsers = await storage.getUsersByRole();
    if (existingUsers.length === 0) {
      const demoUser = await storage.createUser({
        username: "demo",
        password: "password",
        fullName: "John Doe",
        role: "student",
        batch: "2025",
        domain: "Computer Science",
        isVerified: true,
        bio: "CS Student & Developer",
        contactEmail: "john.doe@university.edu"
      });
      const alumni = await storage.createUser({
        username: "alumni",
        password: "password",
        fullName: "Jane Smith",
        role: "alumni",
        batch: "2020",
        company: "Google",
        domain: "Software Engineering",
        isVerified: true,
        bio: "Senior Software Engineer at Google",
        contactEmail: "jane.smith@alumni.com",
        contactLinkedIn: "linkedin.com/in/janesmith"
      });

      await storage.createMarketplaceItem({
        title: "Engineering Mathematics Textbook",
        description: "Used condition, 5th edition. Essential for first years.",
        price: 500, // $5.00
        condition: "used",
        category: "books",
        sellerId: demoUser.id,
        status: "available"
      });

      await storage.createLostFoundItem({
        title: "Blue Water Bottle",
        description: "Left in Library 2nd floor",
        location: "Library",
        type: "found",
        reporterId: demoUser.id,
        status: "reported"
      });

      await storage.createAcademyResource({
        title: "Data Structures Notes",
        subject: "CS101",
        description: "Comprehensive notes on Trees and Graphs",
        uploaderId: demoUser.id,
        fileUrl: "https://example.com/notes.pdf",
        tags: ["CS", "DSA"]
      });

      await storage.createInternship({
        title: "Frontend Developer Intern",
        company: "TechStart Inc",
        type: "remote",
        domain: "Software",
        description: "3 month internship for React developers.",
        applyLink: "https://example.com/apply"
      });

      await storage.createReferral({
        title: "Software Engineer I",
        company: "Google",
        referrerId: alumni.id,
        description: "Looking for strong problem solvers. I can refer for L3 roles.",
        requirements: "DSA, System Design"
      });
    }
  } catch (e) {
    console.error("Seeding failed:", e);
  }

  return httpServer;
}
